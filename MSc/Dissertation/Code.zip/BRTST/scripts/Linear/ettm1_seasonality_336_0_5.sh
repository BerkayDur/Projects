if [ ! -d "./logs" ]; then
    mkdir ./logs
fi

if [ ! -d "./logs/LongForecasting" ]; then
    mkdir ./logs/LongForecasting
fi
seq_len=336
model_name=DLinear

root_path_name=./dataset/
data_path_name=ETTm1_seasonality_336_0_5.csv
model_id_name=ETTm1_seasonality_336_0_5
data_name=custom

random_seed=2021

python -u run_longExp.py \
  --is_training 1 \
  --root_path $root_path_name \
  --data_path $data_path_name \
  --model_id ETTh1_$seq_len'_'336 \
  --model $model_name \
  --data custom \
  --features M \
  --seq_len $seq_len \
  --pred_len 96 \
  --enc_in 7 \
  --des 'Exp' \
  --itr 1 --batch_size 128 --learning_rate 0.005 >logs/LongForecasting/$model_name'_'ETTm1_seasonality_336_0_5_$seq_len'_'96.log