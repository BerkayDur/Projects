if [ ! -d "./logs" ]; then
    mkdir ./logs
fi

if [ ! -d "./logs/recreate" ]; then
    mkdir ./logs/recreate
fi

if [ ! -d "./logs/recreate/BlockRecurrentPatch" ]; then
    mkdir ./logs/recreate/BlockRecurrentPatch
fi

if [ ! -d "./logs/recreate/BlockRecurrentPatch/etth2" ]; then
    mkdir ./logs/recreate/BlockRecurrentPatch/etth2
fi

model_name=BlockRecurrentTST

      
layers='["block"]'      
use_patching=1         
num_heads=16            
d_ff=512                
proj_dim=128            
state_dim=64            
embed_dim=32           
patch_len=16            
stride=8                
use_cache=1             
use_cached_key=0        
share_queries=0         
reset_state=0
window_size=6           
dropout_rate=0.2      
coder_pre_attn_norm="instance"
coder_attn_log_norm="batch"
coder_log_act_norm="none"
coder_post_act_norm="none"
coder_activation="none"
res_attn=0
res_ffnn=1
projection_normalization="none"
mlp_normalization="instance"
projection_pre_normalization=1
mlp_activation="elu"       
bias=1
use_batch_state_enc=0
revin=1
use_mask=1
use_state=1


root_path_name=./dataset/
data_path_name=ETTh2.csv
model_id_name=ETTh2
data_name=ETTh2

# random_seed=2021
batch_size=128


for random_seed in 2021 2022 2023; do
  for seq_len in 96 192 336 720; do
    for pred_len in 96 192 336 720; do
      python -u run_longExp.py \
            --dataset_name "etth2" \
            --random_seed $random_seed \
            --is_training 1 \
            --root_path $root_path_name \
            --data_path $data_path_name \
            --model_id $model_id_name_$seq_len'_'$pred_len \
            --model $model_name \
            --data $data_name \
            --features M \
            --seq_len $seq_len \
            --pred_len $pred_len \
            --layers $layers \
            --use_patching $use_patching \
            --input_sequence_len $seq_len \
            --output_sequence_len $pred_len \
            --c_in 7 \
            --num_heads $num_heads \
            --d_ff $d_ff \
            --proj_dim $proj_dim \
            --state_dim $state_dim \
            --embed_dim $embed_dim \
            --patch_len $patch_len \
            --stride $stride \
            --use_cache $use_cache \
            --use_cached_key $use_cached_key \
            --share_queries $share_queries \
            --reset_state $reset_state\
            --window_size $window_size \
            --dropout_rate $dropout_rate \
            --attn_dropout 0.0 \
            --projection_dropout 0.0 \
            --head_dropout 0.0 \
            --bias $bias \
            --revin $revin \
            --coder_pre_attn_norm $coder_pre_attn_norm \
            --coder_attn_log_norm $coder_attn_log_norm \
            --coder_log_act_norm $coder_log_act_norm \
            --coder_post_act_norm $coder_post_act_norm \
            --coder_activation $coder_activation \
            --res_attn $res_attn \
            --res_ffnn $res_ffnn \
            --projection_normalization $projection_normalization \
            --mlp_normalization $mlp_normalization \
            --projection_pre_norm $projection_pre_normalization \
            --mlp_activation $mlp_activation \
            --mlp_dropout_after_activation 0 \
            --use_batch_state_enc $use_batch_state_enc \
            --affine 1 \
            --subtract_last 0 \
            --use_mask $use_mask \
            --use_state $use_state \
            --des 'Exp' \
            --train_epochs 50\
            --patience 5\
            --lradj 'TST'\
            --pct_start 0.4\
            --itr 1 --batch_size $batch_size --learning_rate 0.0001 \
            >logs/recreate/BlockRecurrentPatch/etth2/$random_seed'_'$model_name'_'$model_id_name'_'$seq_len'_'$pred_len'_'$use_patching'_'$layers'_'$num_heads'_'$d_ff'_'$proj_dim'_'$state_dim'_'$embed_dim'_'$patch_len'_'$stride'_'$use_cache'_'$use_cached_key'_'$share_queries'_'$reset_state'_'$window_size'_'$dropout_rate'_'$coder_pre_attn_norm'_'$coder_attn_log_norm'_'$coder_log_act_norm'_'$coder_post_act_norm'_'$coder_activation'_'$res_attn'_'$res_ffnn'_'$mlp_activation'_'$bias'_'$projection_normalization'_'$mlp_normalization'_'$projection_pre_normalization'_'$use_batch_state_enc'_'$revin'_'$batch_size'_'$use_mask'_'$use_state.log 
    done
  done
done