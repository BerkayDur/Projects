﻿
# The Block-Recurrent Time-Series Transformer (BRTST)

This is the implementation of the my model, the BRTST.

# WARNINGS

1. Running the code creates 2 large files for each model. One is contained under the checkpoints folder and the other under the results folder. For this reason, we choose not to include them in the submitted folder.

2. Running the code will log the results in a different folder (logs/recreate/) to ensure my logs are still available.


# Execution

I would recommend executing the code in the following python file included
```
Execute_code.ipynb
```


# Experimental Framework

The code uses the experimental framework introduced by the [Informer](https://github.com/zhouhaoyi/Informer2020) paper and [Autoformer](https://github.com/thuml/Autoformer) paper. Our specific version is taken from the official implementation of [PatchTST](https://github.com/yuqinie98/PatchTST).

# Script

The code to recreate the experiments of the BRTST are available as a script (.sh file) under
```
scripts/BlockRecurrentTransformer
```



In this folder, scripts beginning with 
```
patch_
```
are to run the BRTST with patching and scripts beginning with
```
no_patch_
```
are to run the BRTST without patching.

# Layers

The code under 
```bash
layers/BlockRecurrent.py
```
contains all the layers used in the BRTST.

Code that contains a url in its description, means that it is taken from elsewhere or my implementation is inspired by some other code. Namely, these are:
- _AttentionOp, line 838
- RotaryEmbedding, line 1128
- RevIN, line 1207


# Models

```
Models/BlockRecurrentTransformer.py
```

Contains the Python file that contains the face of the model.

# test_results

```
test_results
```

contains some graphs showing the predictions given the context.

# exp

```
exp/exp_main.py
```

Contains the python code to run and execute the model.

Modifications are indicated by the following comment at the end of the line
```python
# Mod
```

# Run_longExp.py

```
run_longExp.py
```

Contains the python code to parse the script and calls exp_main.py. This file contains descriptions of each of the arguments. Notably, lines 37 - 76 contains my contributions to this file.

# Results.gsheet

Simply contains the my results in a Google Sheets format

# 'hyperparameter search.gsheet'

Contains the documentation of my hyperparameter search.

# Logs

```
logs/BlockRecurrentNoPatch
```
contains the results of the experiments reported in the paper for no patching.

```
logs/BlockRecurrentPatch
```
contains the results of the experiments reported in the paper for patching.

```
logs/HyperparameterSearch
```
contains the results of my hyperparameter search. Use the google sheets to help navigate it.

```
logs/CodeDemo
```
contains the results of the Code Demonstration.


# Acknowledgements

<https://github.com/yuqinie98/PatchTST>

<https://github.com/ts-kim/RevIN/tree/master>

<https://github.com/lucidrains/rotary-embedding-torch/tree/main>

<https://github.com/dashstander/block-recurrent-transformer/tree/main>
