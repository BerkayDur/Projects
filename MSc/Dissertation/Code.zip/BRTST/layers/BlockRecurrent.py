__all__ = ["Backbone", ]

import torch
from torch import einsum, nn, Tensor
import torch.nn.functional as F
import json

from einops import rearrange, repeat
from typing import Callable, Optional

################
##            ##
##  Backbone  ##
##            ##
################

class Backbone(nn.Module):
  """
  Performs the main operations of the BRTST.
  """
  def __init__(
    self,
    layers,
    use_patching,
    input_sequence_len,
    output_sequence_len,
    c_in,
    num_heads,
    d_ff,
    proj_dim,
    state_dim,
    embed_dim,
    patch_len,
    stride,
    use_cache,
    use_cached_key,
    share_queries,
    reset_state,
    window_size,
    dropout_rate,
    attn_dropout,
    projection_dropout,
    head_dropout,
    bias,
    coder_pre_attn_norm,
    coder_attn_log_norm,
    coder_log_act_norm,
    coder_post_act_norm,
    coder_activation,
    res_attn,
    res_ffnn,
    projection_normalization,
    mlp_normalization,
    projection_pre_norm,
    mlp_activation,
    mlp_dropout_after_activation,
    use_batch_state_enc,
    affine,
    subtract_last,
    revin,
    use_mask,
    use_state
    ):
    super().__init__()



    self.use_patching = use_patching
    self.coder_in = input_sequence_len
    self.coder_channels = c_in

    # RevIn
    self.revin = revin
    if self.revin: self.revin_layer = RevIN(c_in, affine=affine, subtract_last=subtract_last)

    # Patching
    if use_patching == True:
      self.patch_len = patch_len
      self.stride = stride
      patch_num = int((input_sequence_len - patch_len)/stride + 2)
      self.padding_patch_layer = nn.ReplicationPad1d((0, stride))
      self.coder_in = patch_num
      self.coder_channels = patch_len

    # Backbone
    self.backbone = TSTICoder(layers, use_patching, self.coder_in, num_heads, d_ff, proj_dim,
                              state_dim, embed_dim, self.coder_channels,
                              use_cache, use_cached_key, share_queries, reset_state, window_size,
                              dropout_rate, attn_dropout, projection_dropout,
                              bias, coder_pre_attn_norm, coder_attn_log_norm, coder_log_act_norm,
                              coder_post_act_norm, coder_activation, res_attn, res_ffnn,
                              projection_normalization, mlp_normalization, projection_pre_norm,
                              mlp_activation, mlp_dropout_after_activation, use_batch_state_enc, use_mask, use_state)

    # Head
    self.head_nf = proj_dim * self.coder_in
    self.n_vars = c_in

    self.head = Flatten_Head(self.n_vars, self.head_nf, output_sequence_len, head_dropout=head_dropout, use_patching=use_patching)


  def forward(self, z):                                                                   # z: [bs x nvars x seq_len]
      # norm
      if self.revin:
          z = z.transpose(-2,-1)
          z = self.revin_layer(z, 'norm')
          z = z.transpose(-2,-1)

      # do patching
      if self.use_patching == True:
        z = self.padding_patch_layer(z)
        z = z.unfold(dimension=-1, size=self.patch_len, step=self.stride)                   # z: [bs x nvars x patch_num x patch_len]
        z = z.permute(0,1,3,2)                                                              # z: [bs x nvars x patch_len x patch_num]


      # model
      z = self.backbone(z)                                                                # z: [bs x nvars x d_model x patch_num]
      z = self.head(z)                                                                    # z: [bs x nvars x target_window]

      # denorm
      if self.revin:
          z = z.transpose(-2,-1)
          z = self.revin_layer(z, 'denorm')
          z = z.transpose(-2,-1)
      return z

####################
##                ##
##  Flatten_Head  ##
##                ##
####################


class Flatten_Head(nn.Module):
  """
  Flattens the input and projects to a specified dimension and reshapes it.
  """
  def __init__(self, n_vars, nf, target_window, head_dropout=0, use_patching=True):
      super().__init__()

      self.use_patching = use_patching
      self.target_window = target_window
      self.n_vars = n_vars
      self.flatten = nn.Flatten(start_dim=-2)
      if use_patching == True:
        self.linear = nn.Linear(nf, target_window)
      else:
        self.linear = nn.Linear(nf, target_window * n_vars)
      self.dropout = nn.Dropout(head_dropout)



  def forward(self, x):                              

    # Flatten
    x = self.flatten(x)
    # Dense Layer
    x = self.linear(x)
    # Dropout
    x = self.dropout(x)
    if self.use_patching == False:
      x = x.reshape((-1, self.n_vars, self.target_window))
    return x

#################
##             ##
##  TSTICoder  ##
##             ##
#################


class TSTICoder(nn.Module):
  """
  Based on whether the model uses patching, it performs a different operation. But it just creates the network.
  """
  def __init__(
    self,
    layers,
    use_patching,
    input_sequence_len,
    num_heads,
    d_ff,
    proj_dim,
    state_dim,
    embed_dim,
    channels,
    use_cache,
    use_cached_key,
    share_queries,
    reset_state,
    window_size,
    dropout_rate,
    attn_dropout,
    projection_dropout,
    bias,
    coder_pre_attn_norm,
    coder_attn_log_norm,
    coder_log_act_norm,
    coder_post_act_norm,
    coder_activation,
    res_attn,
    res_ffnn,
    projection_normalization,
    mlp_normalization,
    projection_pre_norm,
    mlp_activation,
    mlp_dropout_after_activation,
    use_batch_state_enc,
    use_mask,
    use_state
  ):
    super().__init__()
    """
    param layers: The layers, either "norm" or a standard transformer Encoder, or "block" for the block-recurrent coder.
    param input_sequence_len: context length
    param coder_pre_attn_norm: normalization method to use pre-attention
    param coder_attn_log_norm: normalization method to use after the attention but before logit
    param coder_log_act_norm: normalization method to use after the logit, but before the activation
    param coder_post_act_norm: normalization method to use post-activation
    param coder_activation: activation function to use on the coder
    param res_attn: Whether to use a residual on the attention Block-Recurrent Cell
    param res_ffnn: Whether to use a residual on the Linear layer of the Coder
    param num_heads: Number of heads
    param d_ff: Projected dim of MLP layer
    param proj_dim: projection dimension
    param state_dim: State dimension
    param embed_dim: embedding dimension
    param dropout: dropout rate
    param attn_dropout: dropout rate on attention
    param share_queries: whether to share queries or not
    param bias: Whether the projection should have a bias or not
    param projection_dropout: dropout rate on projection layers
    param projection_normalization: normalization method on projection
    param projection_pre_norm: Should the projection layer normalize before projection
    param reset_state: Whether the state should be reset after each run
    param window_size: window size to use
    param use_cache: whether to use a cache on the attentions
    param use_cached_key: Whether to cache key and value or score and value
    param use_batch_state_enc: Whether the state encoding should have a learnable batch dimension
    param mlp_activation: activation of MLP layer
    param mlp_normalization: normalization of MLP layer
    param mlp_dropout_after_activation: whether the MLP layer should have dropout after activation
    param use_mask: Whether to use a causal sliding window mask or not
    param use_state: Whether to use a state
    """

    self.use_patching = use_patching
    self.W_P = nn.Linear(channels, proj_dim)

    self.coder = TSTCoder(layers, input_sequence_len, num_heads, d_ff, proj_dim,
                          state_dim, embed_dim, use_cache, use_cached_key, share_queries,
                          reset_state, window_size, dropout_rate, attn_dropout,
                          projection_dropout, bias, coder_pre_attn_norm, coder_attn_log_norm,
                          coder_log_act_norm, coder_post_act_norm, coder_activation,
                          res_attn, res_ffnn, projection_normalization,
                          mlp_normalization, projection_pre_norm,
                          mlp_activation, mlp_dropout_after_activation, use_batch_state_enc, use_mask, use_state)

  def _patching_forward(self, x):
        n_vars = x.shape[1]
        # Input encoding
        x = x.permute(0,1,3,2)                                                   # x: [bs x nvars x patch_num x patch_len]
        x = self.W_P(x)                                                          # x: [bs x nvars x patch_num x d_model]

        u = torch.reshape(x, (x.shape[0]*x.shape[1],x.shape[2],x.shape[3]))      # u: [bs * nvars x patch_num x d_model]

        # Encoder
        z = self.coder(u)                                                        # z: [bs * nvars x patch_num x d_model]
        z = torch.reshape(z, (-1,n_vars,z.shape[-2],z.shape[-1]))                # z: [bs x nvars x patch_num x d_model]
        z = z.permute(0,1,3,2)                                                   # z: [bs x nvars x d_model x patch_num]

        return z

  def _no_patching_forward(self, x):
    n_vars = x.shape[1]

    x = x.permute(0, 2, 1)
    x = self.W_P(x)
    x = self.coder(x)
    x = x.permute(0, 2, 1)
    return x


  def forward(self, x):
    if self.use_patching == True:
      return self._patching_forward(x)
    return self._no_patching_forward(x)

################
##            ##
##  TSTCoder  ##
##            ##
################


class TSTCoder(nn.Module):
  """
  This layer creates the layers of the network that perform the feature extraction, between the projection layer and the Flatten head.
  """
  def __init__(
    self,
    layers,
    input_sequence_len,
    num_heads,
    d_ff,
    proj_dim,
    state_dim,
    embed_dim,
    use_cache,
    use_cached_key,
    share_queries,
    reset_state,
    window_size,
    dropout_rate,
    attn_dropout,
    projection_dropout,
    bias,
    coder_pre_attn_norm,
    coder_attn_log_norm,
    coder_log_act_norm,
    coder_post_act_norm,
    coder_activation,
    res_attn,
    res_ffnn,
    projection_normalization,
    mlp_normalization,
    projection_pre_norm,
    mlp_activation,
    mlp_dropout_after_activation,
    use_batch_state_enc,
    use_mask,
    use_state
  ):
    super().__init__()
    """
    param layers: The layers, either "norm" or a standard transformer Encoder, or "block" for the block-recurrent coder.
    param input_sequence_len: context length
    param coder_pre_attn_norm: normalization method to use pre-attention
    param coder_attn_log_norm: normalization method to use after the attention but before logit
    param coder_log_act_norm: normalization method to use after the logit, but before the activation
    param coder_post_act_norm: normalization method to use post-activation
    param coder_activation: activation function to use on the coder
    param res_attn: Whether to use a residual on the attention Block-Recurrent Cell
    param res_ffnn: Whether to use a residual on the Linear layer of the Coder
    param num_heads: Number of heads
    param d_ff: Projected dim of MLP layer
    param proj_dim: projection dimension
    param state_dim: State dimension
    param embed_dim: embedding dimension
    param dropout: dropout rate
    param attn_dropout: dropout rate on attention
    param share_queries: whether to share queries or not
    param bias: Whether the projection should have a bias or not
    param projection_dropout: dropout rate on projection layers
    param projection_normalization: normalization method on projection
    param projection_pre_norm: Should the projection layer normalize before projection
    param reset_state: Whether the state should be reset after each run
    param window_size: window size to use
    param use_cache: whether to use a cache on the attentions
    param use_cached_key: Whether to cache key and value or score and value
    param use_batch_state_enc: Whether the state encoding should have a learnable batch dimension
    param mlp_activation: activation of MLP layer
    param mlp_normalization: normalization of MLP layer
    param mlp_dropout_after_activation: whether the MLP layer should have dropout after activation
    param use_mask: Whether to use a causal sliding window mask or not
    param use_state: Whether to use a state
    """

    self.layers=[]
    self.input_sequence_len = input_sequence_len
    self.coder_pre_attn_norm = coder_pre_attn_norm
    self.coder_attn_log_norm = coder_attn_log_norm
    self.coder_log_act_norm = coder_log_act_norm
    self.coder_post_act_norm = coder_post_act_norm
    self.coder_activation = coder_activation
    self.res_attn = res_attn
    self.res_ffnn = res_ffnn
    self.num_heads = num_heads
    self.proj_dim = proj_dim
    self.state_dim = state_dim
    self.embed_dim = embed_dim
    self.d_ff = d_ff
    self.dropout_rate = dropout_rate
    self.attn_dropout = attn_dropout
    self.bias = bias
    self.projection_dropout = projection_dropout
    self.projection_normalization = projection_normalization
    self.projection_pre_norm = projection_pre_norm
    self.mlp_activation = mlp_activation
    self.mlp_normalization = mlp_normalization
    self.mlp_dropout_after_activation = mlp_dropout_after_activation
    self.share_queries = share_queries
    self.reset_state = reset_state
    self.window_size = window_size
    self.use_cache = use_cache
    self.use_cached_key = use_cached_key
    self.use_batch_state_enc = use_batch_state_enc
    self.use_mask = use_mask
    self.use_state = use_state



    self.create_layers(layers)


  def create_layers(self, layers):
    for layer in layers:
      if layer == "norm":
        self.layers.append(
            StandardCoderLayer(self.input_sequence_len, self.coder_pre_attn_norm, self.coder_attn_log_norm,
                               self.coder_log_act_norm, self.coder_post_act_norm, self.coder_activation,
                               self.num_heads, self.proj_dim, self.embed_dim,
                               self.d_ff, self.dropout_rate, self.attn_dropout,
                               self.bias, self.projection_dropout,
                               self.projection_normalization, self.projection_pre_norm,
                               self.window_size, self.mlp_activation, self.mlp_normalization,
                               self.mlp_dropout_after_activation)
        )
      elif layer == "block":
        self.layers.append(
            BlockRecurrentCoderLayer(
                self.input_sequence_len, self.coder_pre_attn_norm, self.coder_attn_log_norm,
                self.coder_log_act_norm, self.coder_post_act_norm, self.coder_activation,
                self.res_attn, self.res_ffnn, self.num_heads, self.d_ff, self.proj_dim,
                self.state_dim, self.embed_dim, self.dropout_rate, self.attn_dropout,
                self.share_queries, self.bias, self.projection_dropout, self.projection_normalization,
                self.projection_pre_norm, self.reset_state, self.window_size, self.use_cache, self.use_cached_key,
                self.use_batch_state_enc, self.mlp_activation, self.mlp_normalization,
                self.mlp_dropout_after_activation, self.use_mask, self.use_state
            )
        )
    self.layers = nn.ModuleList(self.layers)

  def forward(self, src):
    output = src

    for layer in self.layers:
      output = layer(output)

    return output

##########################
##                      ##
##  StandardCoderLayer  ##
##                      ##
##########################


class StandardCoderLayer(nn.Module):
  """
  Standard Transformer Encoder layer.
  """
  def __init__(self, input_sequence_len, coder_pre_attn_norm:str, coder_attn_log_norm:str,
               coder_log_act_norm:str, coder_post_act_norm:str, coder_activation:str,
               num_heads, proj_dim, embed_dim, d_ff, dropout_rate, attn_dropout,
               bias, projection_dropout, projection_normalization, projection_pre_norm,
               window_size, mlp_activation, mlp_normalization, mlp_dropout_after_activation,
               use_mask):
    super().__init__()

    self.input_sequence_len = input_sequence_len
    self.window_size = window_size

    self.attn = AttentionWithBackProjection(input_sequence_len, num_heads, proj_dim, embed_dim, attn_dropout,
                                            False, False, bias, projection_dropout,
                                            projection_normalization, projection_pre_norm)
    self.query_proj = Projection(input_sequence_len, proj_dim, embed_dim, bias, projection_dropout,
                                 projection_normalization, projection_pre_norm)
    self.key_proj = Projection(input_sequence_len, proj_dim, embed_dim, bias, projection_dropout,
                                 projection_normalization, projection_pre_norm)
    self.value_proj = Projection(input_sequence_len, proj_dim, embed_dim, bias, projection_dropout,
                                 projection_normalization, projection_pre_norm)

    self.mlp_layer = MLPLayer(input_sequence_len, proj_dim, d_ff, dropout_rate, mlp_activation,
                              mlp_normalization, mlp_dropout_after_activation)

    self.pre_attn_norm = Get_Normalization(coder_pre_attn_norm, proj_dim, transpose=True, input_shape=[proj_dim, input_sequence_len])
    self.attn_log_norm = Get_Normalization(coder_attn_log_norm, proj_dim, transpose=True, input_shape=[proj_dim, input_sequence_len])
    self.log_act_norm = Get_Normalization(coder_log_act_norm, proj_dim, transpose=True, input_shape=[proj_dim, input_sequence_len])
    self.post_act_norm = Get_Normalization(coder_post_act_norm, proj_dim, transpose=True, input_shape=[proj_dim, input_sequence_len])

    self.activation = Get_Activation(coder_activation)


  def _create_mask(self, device):
    # maybe +1
    if self.use_mask == True:
      self.mask = create_sliding_window_mask(self.input_sequence_len, self.input_sequence_len, self.window_size+1, -self.window_size, device)
    else:
      self.mask = None

  def forward(self, x, mask=None):
    x = self.pre_attn_norm(x)

    q, k, v = self.query_proj(x), self.key_proj(x), self.value_proj(x)
    attn = self.attn(q, k, v, mask)

    x = x + attn

    x = self.attn_log_norm(x)

    x = x + self.mlp_layer(x)

    x = self.log_act_norm(x)
    x = self.activation(x)
    x = self.post_act_norm(x)


    return x

################################
##                            ##
##  BlockRecurrentCoderLayer  ##
##                            ##
################################


class BlockRecurrentCoderLayer(nn.Module):
  """
  Performs the operations of the Block-Recurrent Coder as outlined in the paper.
  """
  def __init__(self, input_sequence_len:int, coder_pre_attn_norm:str, coder_attn_log_norm:str,
               coder_log_act_norm:str, coder_post_act_norm:str, coder_activation:str,
               res_attn:bool, res_ffnn:bool, num_heads:int, d_ff:int, proj_dim:int, state_dim:int,
               embed_dim:int, dropout:float, attn_dropout:float=0.0, share_queries:bool=False,
               bias:bool=False, projection_dropout:float=0.0, projection_normalization:str="layer",
               projection_pre_norm:bool=False, reset_state:bool=False, window_size:int=8, use_cache:bool=True,
               use_cached_key:bool=False, use_batch_state_enc:bool=False,
               mlp_activation:str="silu", mlp_normalization:str="layer",
               mlp_dropout_after_activation:bool=False, use_mask:bool=True, use_state:bool=True):
    super().__init__()
    """
    param input_sequence_len: context length
    param coder_pre_attn_norm: normalization method to use pre-attention
    param coder_attn_log_norm: normalization method to use after the attention but before logit
    param coder_log_act_norm: normalization method to use after the logit, but before the activation
    param coder_post_act_norm: normalization method to use post-activation
    param coder_activation: activation function to use on the coder
    param res_attn: Whether to use a residual on the attention Block-Recurrent Cell
    param res_ffnn: Whether to use a residual on the Linear layer of the Coder
    param num_heads: Number of heads
    param d_ff: Projected dim of MLP layer
    param proj_dim: projection dimension
    param state_dim: State dimension
    param embed_dim: embedding dimension
    param dropout: dropout rate
    param attn_dropout: dropout rate on attention
    param share_queries: whether to share queries or not
    param bias: Whether the projection should have a bias or not
    param projection_dropout: dropout rate on projection layers
    param projection_normalization: normalization method on projection
    param projection_pre_norm: Should the projection layer normalize before projection
    param reset_state: Whether the state should be reset after each run
    param window_size: window size to use
    param use_cache: whether to use a cache on the attentions
    param use_cached_key: Whether to cache key and value or score and value
    param use_batch_state_enc: Whether the state encoding should have a learnable batch dimension
    param mlp_activation: activation of MLP layer
    param mlp_normalization: normalization of MLP layer
    param mlp_dropout_after_activation: whether the MLP layer should have dropout after activation
    param use_mask: Whether to use a causal sliding window mask or not
    param use_state: Whether to use a state
    """

    self.window_size = window_size
    self.attn = BlockRecurrentCell(input_sequence_len, num_heads, d_ff, proj_dim, state_dim,
                                   embed_dim, dropout, attn_dropout, share_queries,
                                   bias, projection_dropout, projection_normalization,
                                   projection_pre_norm, reset_state, window_size, use_cache,
                                   use_cached_key, use_batch_state_enc, mlp_activation,
                                   mlp_normalization, mlp_dropout_after_activation, use_mask, use_state)

    # self.to_logits = MLPLayer(input_sequence_len, proj_dim, d_ff, dropout, mlp_activation, mlp_normalization, mlp_dropout_after_activation)
    self.to_logits = nn.Linear(proj_dim, proj_dim, bias=False)

    self.pre_attn_norm = Get_Normalization(coder_pre_attn_norm, proj_dim, transpose=True, input_shape=[proj_dim, input_sequence_len])
    self.attn_log_norm = Get_Normalization(coder_attn_log_norm, proj_dim, transpose=True, input_shape=[proj_dim, input_sequence_len])
    self.log_act_norm = Get_Normalization(coder_log_act_norm, proj_dim, transpose=True, input_shape=[proj_dim, input_sequence_len])
    self.post_act_norm = Get_Normalization(coder_post_act_norm, proj_dim, transpose=True, input_shape=[proj_dim, input_sequence_len])

    self.activation = Get_Activation(coder_activation)

    self.res_attn = res_attn
    self.res_ffnn = res_ffnn

    self.rotary_pos_emb = RotaryEmbedding(dim = embed_dim,
                                          width = 2 * input_sequence_len,
                                          scale_base = input_sequence_len)

  def forward(self, x):
    ##  Input: [Batch, Sequence Len, Proj Dim]
    ## Output: [Batch, Sequence Len, Proj Dim]
    device = x.device

    rotary_pos_emb, xpos_scale = self.rotary_pos_emb(device)

    residual_attn = x

    x = self.pre_attn_norm(x)
    x = self.attn(x, rotary_pos_emb, xpos_scale)

    if self.res_attn == True:
      x = x + residual_attn

    x = self.attn_log_norm(x)

    residual_logits = x

    x = self.to_logits(x)

    if self.res_ffnn == True:
      x = x + residual_attn

    x = self.log_act_norm(x)
    x = self.activation(x)
    x = self.post_act_norm(x)

    return x

##########################
##                      ##
##  BlockRecurrentCell  ##
##                      ##
##########################


class BlockRecurrentCell(nn.Module):
  """
  This layer performs the operations of the block-recurrent cell as outlined in the paper.
  """
  def __init__(self, input_sequence_len:int, num_heads:int, d_ff:int, proj_dim:int,
               state_dim:int, embed_dim:int, dropout:float, attn_dropout:float=0.0,
               share_queries:bool=False, bias:bool=False, projection_dropout:float=0.0,
               projection_normalization:str="layer", projection_pre_norm:bool=False,
               reset_state:bool=False, window_size:int=8, use_cache:bool=True,
               use_cached_key:bool=False, use_batch_state_enc:bool=False,
               mlp_activation:str="silu", mlp_normalization:str="layer",
               mlp_dropout_after_activation:bool=False, use_mask:bool=True, use_state:bool=True):
    super().__init__()
    """
    param input_sequence_len: context length
    param num_heads: Number of heads
    param d_ff: Projected dim of MLP layer
    param proj_dim: projection dimension
    param state_dim: State dimension
    param embed_dim: embedding dimension
    param dropout: dropout rate
    param attn_dropout: dropout rate on attention
    param share_queries: whether to share queries or not
    param bias: Whether the projection should have a bias or not
    param projection_dropout: dropout rate on projection layers
    param projection_normalization: normalization method on projection
    param projection_pre_norm: Should the projection layer normalize before projection
    param reset_state: Whether the state should be reset after each run
    param window_size: window size to use
    param use_cache: whether to use a cache on the attentions
    param use_cached_key: Whether to cache key and value or score and value
    param use_batch_state_enc: Whether the state encoding should have a learnable batch dimension
    param mlp_activation: activation of MLP layer
    param mlp_normalization: normalization of MLP layer
    param mlp_dropout_after_activation: whether the MLP layer should have dropout after activation
    param use_mask: Whether to use a causal sliding window mask or not
    param use_state: Whether to use a state
    """

    self.window_size = window_size
    self.state_dim = state_dim
    self.use_batch_state_enc = use_batch_state_enc
    self.reset_state = reset_state

    self.key_state = Projection(window_size, state_dim, embed_dim, bias, projection_dropout,
                                projection_normalization, projection_pre_norm)
    self.value_state = Projection(window_size, state_dim, embed_dim, bias, projection_dropout,
                                projection_normalization, projection_pre_norm)
    self.key_emb = Projection(input_sequence_len, proj_dim, embed_dim, bias, projection_dropout,
                                projection_normalization, projection_pre_norm)
    self.value_emb = Projection(input_sequence_len, proj_dim, embed_dim, bias, projection_dropout,
                                projection_normalization, projection_pre_norm)

    self.vertical_query_state = Projection(input_sequence_len, proj_dim, embed_dim, bias, projection_dropout,
                                projection_normalization, projection_pre_norm)
    self.horizontal_query_state = Projection(window_size, state_dim, embed_dim, bias, projection_dropout,
                                projection_normalization, projection_pre_norm)
    if share_queries == False:
      self.vertical_query_emb = Projection(input_sequence_len, proj_dim, embed_dim, bias, projection_dropout,
                                projection_normalization, projection_pre_norm)
      self.horizontal_query_emb = Projection(window_size, state_dim, embed_dim, bias, projection_dropout,
                                projection_normalization, projection_pre_norm)
    else:
      self.vertical_query_emb = self.vertical_query_state
      self.horizontal_query_emb = self.horizontal_query_state

    self.vertical_cross_attn = _AttentionOp(num_heads, embed_dim, attn_dropout, use_cache,
                                            use_cached_key)
    self.vertical_self_attn = _AttentionOp(num_heads, embed_dim, attn_dropout, use_cache,
                                            use_cached_key)

    self.horizontal_self_attn = _AttentionOp(num_heads, embed_dim, attn_dropout, use_cache,
                                            use_cached_key)
    self.horizontal_cross_attn = _AttentionOp(num_heads, embed_dim, attn_dropout, use_cache,
                                            use_cached_key)


    self.vertical_proj = nn.Linear(2*embed_dim, proj_dim, bias=False)
    self.horizontal_proj = nn.Linear(2*embed_dim, state_dim, bias=False)

    self.vertical_ff = MLPLayer(window_size, proj_dim, d_ff, dropout, mlp_activation, mlp_normalization,
                                mlp_dropout_after_activation)
    self.horizontal_ff = MLPLayer(window_size, state_dim, d_ff, dropout, mlp_activation, mlp_normalization,
                                mlp_dropout_after_activation)

    self.horizontal_proj_gate = LSTMGateSimple(state_dim)
    self.horizontal_ff_gate = LSTMGateSimple(state_dim)

    self.register_buffer("state", None)


  def _create_mask(self, device):
    # maybe +1
    self.mask = create_sliding_window_mask(self.window_size, 2*self.window_size, self.window_size+1, 0, device)

  def _create_state(self, batch, device):
    self.state = torch.zeros((batch, self.window_size, self.state_dim), device=device)
    if self.use_batch_state_enc:
      self.state_enc = nn.Parameter(torch.randn((batch, self.window_size, self.state_dim), device=device), requires_grad=True)
    else:
      self.state_enc = nn.Parameter(torch.randn((1, self.window_size, self.state_dim), device=device), requires_grad=True)

  def _step(self, x, k_e, v_e, q_s_v, q_e_v, i):
    state = self.state + self.state_enc

    k_s = self.key_state(state)
    v_s = self.value_state(state)
    q_s_h = self.horizontal_query_state(state)
    q_e_h = self.horizontal_query_emb(state)

    vertical_cross_attn = self.vertical_cross_attn(q_s_v, k_s, v_s, self.mask)
    vertical_self_attn = self.vertical_self_attn(q_e_v, k_e, v_e, self.mask)

    horizontal_cross_attn = self.horizontal_cross_attn(q_e_h, k_e, v_e, self.mask)
    horizontal_self_attn = self.horizontal_self_attn(q_s_h, k_s, v_s, self.mask)

    vertical_proj = self.vertical_proj(torch.concat((vertical_cross_attn, vertical_self_attn), dim=2))
    horizontal_proj = self.horizontal_proj(torch.concat((horizontal_cross_attn, horizontal_self_attn), dim=2))

    vertical_proj = vertical_proj + x
    x = self.vertical_ff(vertical_proj) + vertical_proj

    horizontal_proj = self.horizontal_proj_gate(horizontal_proj, state)
    state = self.horizontal_ff_gate(self.horizontal_ff(horizontal_proj), horizontal_proj)

    self.state = state.detach()

    return x

  def forward(self, x:Tensor, rotary_pos_emb:Optional[Tensor]=None, xpos_scale:Optional[Tensor]=None):
    ##  Input: x - [Batch, Sequence Length, Proj Dim]
    ## Output: [Batch, Sequence Length, Proj Dim]

    batch, seq_len, device = x.shape[0], x.shape[1], x.device

    if self.state == None:
      self._create_mask(device=device)
      self._create_state(batch, device=device)

    if self.reset_state == True:
      self._create_state(batch, device=device)
    k_e = self.key_emb(x)
    v_e = self.value_emb(x)

    q_s_v = self.vertical_query_state(x)
    q_e_v = self.vertical_query_emb(x)

    if rotary_pos_emb != None:
      q_e_v = apply_rotary_pos_emb(q_e_v, rotary_pos_emb, xpos_scale)
      k_e = apply_rotary_pos_emb(k_e, rotary_pos_emb, xpos_scale ** -1)

    num_iters = seq_len // self.window_size

    x = torch.concat([self._step(x[:,i*self.window_size:(i+1)*self.window_size,:],
                                 k_e[:,i*self.window_size:(i+1)*self.window_size,:],
                                 v_e[:,i*self.window_size:(i+1)*self.window_size,:],
                                 q_s_v[:,i*self.window_size:(i+1)*self.window_size,:],
                                 q_e_v[:,i*self.window_size:(i+1)*self.window_size,:], i)
                      for i in range(num_iters)
                    ], dim=1)

    return x



###################################
##                               ##
##  AttentionWithBackProjection  ##
##                               ##
###################################

class AttentionWithBackProjection(nn.Module):
  """
  Performs attention, as defined in _AttentionOp, with a projection back to a specified dimension
  """
  def __init__(self, input_sequence_len:int, num_heads:int, in_dim:int, embed_dim:int,
               attn_dropout:float=0.0, use_cache:bool=False, use_cached_key:bool=True,
               bias:bool=False, projection_dropout:float=0.0,
               projection_normalization:str="layer", projection_pre_norm:bool=False):
    """
    param input_sequence_len: context length
    param num_heads: Number of heads
    param in_dim: Dimension to project back to
    param embed_dim: The dimension of the embedding
    param attn_dropout: The dropout rate on the attention heads
    param use_cache: Whether to use the non-differentiable cache or not
    param use_cached_key: Whether to cache the key and value or the score and value.
    param bias: Whether the projection should have a bias or not
    param dropout_rate: Dropout Rate on projection
    param normalization: Normalization method used with projection
    param pre_norm: Should the normalization be performed before the expansion in the projection.
    """
    super().__init__()

    self.attn = _AttentionOp(num_heads, embed_dim, attn_dropout, use_cache)
    self.proj = Projection(input_sequence_len, embed_dim, in_dim, bias, projection_dropout,
                           projection_normalization, projection_pre_norm)

  def forward(self, query, key, value, mask=None):
    ##  Input : query - [Batch x Window Size x Embed Dim], key - [Batch x Window Size x Embed Dim], value - [Batch x Window Size x Embed Dim], mask - should be sliding window mask
    ## Output : attn_output - [Batch x Window Size x In Dim]
    x = self.attn(query, key, value, mask)
    x = self.proj(x)
    return x

####################
##                ##
##  _AttentionOp  ##
##                ##
####################

class _AttentionOp(nn.Module):
  """
  Standard Multi-head scaled-dot product attention with the option for a non-differentiable cache.
  Inspired by: https://github.com/dashstander/block-recurrent-transformer/blob/main/block_recurrent_transformer/transformer.py#L83
  """
  def __init__(self, num_heads:int, embed_dim:int, attn_dropout:float=0.0,
               use_cache:bool=False, use_cached_key:bool=True):
    """
    param num_heads: Number of heads
    param embed_dim: The dimension of the embedding
    param attn_dropout: The dropout rate on the attention heads
    param use_cache: Whether to use the non-differentiable cache or not
    param use_cached_key: Whether to cache the key and value or the score and value.
    """
    super().__init__()

    self.use_cache = use_cache
    self.use_cached_key = use_cached_key
    self.initialized_cache = False

    if use_cache == True and use_cached_key == True:
      self.register_buffer("cache_key", None)
      self.register_buffer("cache_value", None)
    if use_cache == True and use_cached_key == False:
      self.register_buffer("cache_score", None)
      self.register_buffer("cache_value", None)


    self.num_heads = num_heads
    self.embed_dim = embed_dim,
    self.attn_dropout = attn_dropout

    self.head_dim = embed_dim // num_heads
    self.scale = self.head_dim ** -0.5
    self.dropout = nn.Dropout(attn_dropout)
    assert self.head_dim * num_heads == embed_dim, "Ensure that embed_dim is divisible by num_heads."

  def _get_cache(self, name:str):
    if name == "key":
      assert self.use_cached_key == True, "_AttentionOp doesn't cache the key, instead it is caching the score."
      return self.cache_key
    elif name == "score":
      assert self.use_cached_key == False, "_AttentionOp doesn't cache the score, instead it is caching the key."
      return self.cache_score
    elif name == "value":
      return self.cache_value

  def _update_cache(self, values:tuple):
    assert len(values) == 2
    if self.use_cached_key == True:
      self.cache_key, self.cache_value = values
    else:
      self.cache_score, self.cache_value = values
    return 0

  def _cat_cached(self, cache_1:Tensor, value:Tensor):
    value = torch.cat((self._get_cache("value"), value), dim=-2)
    if self.use_cached_key == True:
      cache_1 = torch.cat((self._get_cache("key"), cache_1), dim=-2)
    else:
      cache_1 = torch.cat((self._get_cache("score"), cache_1), dim=-1)

    return (cache_1, value)

  def _initialize_cache(self, batch_size:int, window_size:int, device):
    if self.use_cached_key == True:
      self._update_cache((torch.zeros((batch_size, self.num_heads, window_size, self.head_dim), device=device),
                          torch.zeros((batch_size, self.num_heads, window_size, self.head_dim), device=device)))
    else:
      self._update_cache((torch.zeros((batch_size, self.num_heads, window_size, window_size), device=device),
                          torch.zeros((batch_size, self.num_heads, window_size, self.head_dim), device=device)))
    self.initialized_cache = True
    return 0



  def forward(self, query:Tensor, key:Tensor, value:Tensor, mask:Optional[Tensor]=None):
    ##  Input : query - [Batch x Window Size x Embed Dim], key - [Batch x Window Size x Embed Dim], value - [Batch x Window Size x Embed Dim], mask - should be sliding window mask
    ## Output : attn_output - [Batch x Window Size x Embed Dim]

    batch_size, window_size, device = query.shape[0], query.shape[1], query.device

    # Initialize Cache
    if self.use_cache == True and self.initialized_cache == False:
      self._initialize_cache(batch_size, window_size, device)

    # Create Heads
    query, key, value = map(lambda t: rearrange(t, "b n (h d) -> b h n d", h = self.num_heads), (query, key, value))

    # Scale Query
    query = query * self.scale

    # If using key cache, ensure to do computation before score calculation
    if self.use_cache == True and self.use_cached_key == True:
      # Set the key and value aside
      _to_be_cached = (key.clone().detach(), value.clone().detach())
      # Append the Cached Values
      key, value = self._cat_cached(key, value)
      # Update Cache
      self._update_cache(_to_be_cached)


    # Compute the attention scores
    score = einsum("b h i d, b h j d -> b h i j", query, key)

    # If using score cache, ensure to do computation after score calculation
    if self.use_cache == True and self.use_cached_key == False:
      # Ser the score and value aside.
      _to_be_cached = (score.clone().detach(), value.clone().detach())
      # Append the Cached Values
      score, value = self._cat_cached(score, value)
      # Update Cache
      self._update_cache(_to_be_cached)

    # Apply the mask if one exists
    if mask != None:
      score = score.masked_fill_(mask, -torch.finfo(score.dtype).max)

    # Compute softmax on scores
    score = score.softmax(dim=-1)
    # Dropout on score
    score = self.dropout(score)

    # Compute Attention Output
    out = score @ value

    # Reshape
    out = rearrange(out, "b h n d -> b n (h d)")

    return out

##################################
##                              ##
##  create_sliding_window_mask  ##
##                              ##
##################################

def create_sliding_window_mask(size1:int, size2:int, window_size:int, offset:int, device):
  """
  Create a sliding window mask
  """
  ## size1 is vertical dim, usually the size of query
  ## size2 is horizontal dim, usually the size of the key
  mask = torch.ones((size1, size2), device=device).triu(diagonal=window_size + offset) + torch.ones((size2, size1), device=device).triu(diagonal=1 - offset).T
  return mask.to(torch.bool)

##################
##              ##
##  Projection  ##
##              ##
##################

class Projection(nn.Module):
  """
  A projection layer that expands the number of channels to a latent dimensions.
  """
  def __init__(self, input_sequence_len:int, in_dim:int, out_dim:int, bias:Optional[bool]=False, dropout_rate:Optional[float]=0.0, normalization:Optional[str]="batch", pre_norm:Optional[bool]=False):
    super().__init__()
    """
    param input_sequence_len: Context length
    param in_dim: The channels
    param out_dim: The latent dimension
    param bias: Whether the projection should have a bias or not
    param dropout_rate: Dropout Rate
    param normalization: Normalization method
    param pre_norm: Should the normalization be performed before the expansion.
    """
    ## dim will either be proj_dim, state_dim, or embed_dim
    if pre_norm == False:
      self.layer = nn.Sequential(
          nn.Linear(in_dim, out_dim, bias=bias),
          Get_Normalization(normalization, out_dim, True, True, [out_dim, input_sequence_len]),
          nn.Dropout(dropout_rate)
      )
    else:
      self.layer = nn.Sequential(
          Get_Normalization(normalization, in_dim, True, True, [in_dim, input_sequence_len]),
          nn.Linear(in_dim, out_dim, bias=bias),
          nn.Dropout(dropout_rate)
      )

  def forward(self, x:Tensor):
    ##  Input : [Batch, Sequence Length, In Dimension]
    ## Output : [Batch, Sequence Length, Out Dimension]
    return self.layer(x)

################
##            ##
##  MLPLayer  ##
##            ##
################



class MLPLayer(nn.Module):
  """
  This MLP Layer is the same as that in the Canonical transformer. Performs a dimensionality expansion to learn
  more complex patterns and relationships then performs a dimensionality reduction to compress and learn the most
  relevant features.
  """
  def __init__(self, input_sequence_len:int, proj_dim:int, d_ff:int, dropout_rate:float, activation:str="silu", normalization:str="batch", dropout_after_activation:bool=False):
    """
    param input_sequence_length: Context length
    param proj_dim: Projection dimension that state recieves and expands to to.
    param d_ff: Dimension to expand to.
    param dropout_rate: dropout rate
    param activation: Activation function
    param normalization: Normalization method
    dropout_after_activation: Dropout after the activation after the dimensionality expansion or after the compression.
    """
    super().__init__()
    inner_dropout = 0. if dropout_after_activation == False else dropout_rate
    self.seq = nn.Sequential(
        nn.Linear(proj_dim, d_ff),
        Get_Activation(activation),
        nn.Dropout(inner_dropout),
        nn.Linear(d_ff, proj_dim),
        nn.Dropout(dropout_rate)
    )
    self.norm = Get_Normalization(normalization, proj_dim, True, True, [proj_dim, input_sequence_len])

  def forward(self, x:Tensor):
    ##  Input : [Batch, Sequence Length, Projection Dimension]
    ## Output : [Batch, Sequence Length, Projection Dimension]

    # Residual connection
    x = x + self.seq(x)
    # Normalization
    x = self.norm(x)
    return x

################
##            ##
##  LSTMGate  ##
##            ##
################



class LSTMGateSimple(nn.Module):
  """
  This LSTM-style gate is originally used to update the cell state. Here it will be used
  to update the state.
  https://github.com/dashstander/block-recurrent-transformer/blob/main/block_recurrent_transformer/transformer.py#L65
  """
  def __init__(self, state_dim:int):
    """
    param state_dim: The dimension of the state.
    """
    super().__init__()
    self.z = nn.Linear(state_dim, state_dim)
    self.i = nn.Linear(state_dim, state_dim)
    self.f = nn.Linear(state_dim, state_dim)
    self.tanh = nn.Tanh()
    self.sigmoid = nn.Sigmoid()

    self.mean = 0.0
    self.bias_std = 0.1
    self.weight_std = (0.1/state_dim)**0.5
    self.trunc_lower = -1
    self.trunc_upper = 1

    ## Initialize as stated in the paper
    nn.init.normal_(self.z.bias, mean=0.0, std=self.bias_std)
    nn.init.normal_(self.i.bias, mean=0.0, std=self.bias_std)
    nn.init.normal_(self.f.bias, mean=0.0, std=self.bias_std)

    nn.init.trunc_normal_(self.z.weight, mean=0.0, std=self.weight_std,
                          a=self.trunc_lower, b=self.trunc_upper)
    nn.init.trunc_normal_(self.i.weight, mean=0.0, std=self.weight_std,
                          a=self.trunc_lower, b=self.trunc_upper)
    nn.init.trunc_normal_(self.f.weight, mean=0.0, std=self.weight_std,
                          a=self.trunc_lower, b=self.trunc_upper)

  def forward(self, x:Tensor, state:Tensor):
    ##  Input : [Batch, Sequence Length, State Dimension]
    ## Output : [Batch, Sequence Length, State Dimension]
    z_t = self.tanh(self.z(x))
    i_t = self.sigmoid(self.i(x) - 1)
    f_t = self.sigmoid(self.f(x) + 1)
    state = state * f_t + z_t  * i_t
    return state

####################################
##                                ##
##  Rotary Embedding & functions  ##
##                                ##
####################################


class RotaryEmbedding(nn.Module):
  """
  Outputs rotary position embeddings.
  https://github.com/dashstander/block-recurrent-transformer/blob/main/block_recurrent_transformer/transformer.py#L40
  """
  def __init__(
      self,
      dim,                
      width,              
      scale_base,         
      theta = 1000        
  ):
    super().__init__()

    self.dim = dim
    self.width = width
    self.scale_base = scale_base
    self.theta = theta
    self.built = False

    self.register_buffer("inv_freq", None, persistent=False)
    self.register_buffer("scale", None, persistent=False)
    self.register_buffer("cached_freqs", None, persistent=False)
    self.register_buffer("cached_scales", None, persistent=False)

  def build(self, device):
    self.built = True

    self.inv_freq = 1. / (self.theta ** (torch.arange(0, self.dim, 2, device=device).float() / self.dim))
    self.scale = (torch.arange(0, self.dim, 2, device=device) + 0.4 * self.dim) / (1.4 * self.dim)


  def forward(self, device):
    if self.built == False:
      self.build(device)

    seq_len = self.width

    if self.cached_freqs != None:
      cached_seq_len = self.cached_freqs.shape[-2]
      if cached_seq_len >= seq_len:
        return self.cached_freqs[:seq_len], self.cached_scales[:seq_len]


    t = torch.arange(seq_len, device=device).type_as(self.inv_freq)
    freqs = torch.einsum("i, j -> i j", t, self.inv_freq)
    freqs = torch.cat((freqs, freqs), dim=-1)

    power = (t - (seq_len //2)) / self.scale_base
    scale = self.scale ** rearrange(power, "n -> n 1")
    scale = torch.cat((scale, scale), dim=-1)

    self.cached_freqs = freqs
    self.cached_scales = scale
    return freqs, scale

def rotate_half(x:Tensor):
  x1, x2 = x.chunk(2, dim=-1)
  return torch.cat((-x2, x1), dim=-1)

def apply_rotary_pos_emb(t, pos, scale=1.):
  seq_len = t.shape[-2]

  assert pos.shape[-2] >= seq_len

  pos = pos[-seq_len:]

  if isinstance(scale, torch.Tensor):
    assert scale.shape[-2] >= seq_len
    scale = scale[-seq_len:]

  return (t*pos.cos() * scale) + (rotate_half(t) * pos.sin() * scale)

#############
##         ##
##  RevIN  ##
##         ##
#############

class RevIN(nn.Module):
  """
  Performs a Reversible Instance Normalization.
  It is useful for Time-series forecasting as it help with modelling non-stationary time-series.

  https://github.com/ts-kim/RevIN/blob/master/RevIN.py
  """
  def __init__(self, num_features:int, eps:Optional[float]=1e-5, affine:Optional[bool]=True, subtract_last:Optional[bool]=False):
      """
      :param num_features: the number of features or channels
      :param eps: a value added for numerical stability
      :param affine: if True, RevIN has learnable affine parameters
      """
      super(RevIN, self).__init__()
      self.num_features = num_features
      self.eps = eps
      self.affine = affine
      self.subtract_last = subtract_last
      if self.affine:
          self._init_params()

  def forward(self, x:Tensor, mode:str):
      if mode == 'norm':
          self._get_statistics(x)
          x = self._normalize(x)
      elif mode == 'denorm':
          x = self._denormalize(x)
      else: raise NotImplementedError
      return x

  def _init_params(self):
      # initialize RevIN params: (C,)
      self.affine_weight = nn.Parameter(torch.ones(self.num_features))
      self.affine_bias = nn.Parameter(torch.zeros(self.num_features))

  def _get_statistics(self, x:Tensor):
      dim2reduce = tuple(range(1, x.ndim-1))
      if self.subtract_last:
          self.last = x[:,-1,:].unsqueeze(1)
      else:
          self.mean = torch.mean(x, dim=dim2reduce, keepdim=True).detach()
      self.stdev = torch.sqrt(torch.var(x, dim=dim2reduce, keepdim=True, unbiased=False) + self.eps).detach()

  def _normalize(self, x:Tensor):
      if self.subtract_last:
          x = x - self.last
      else:
          x = x - self.mean
      x = x / self.stdev
      if self.affine:
          x = x * self.affine_weight
          x = x + self.affine_bias
      return x

  def _denormalize(self, x:Tensor):
      if self.affine:
          x = x - self.affine_bias
          x = x / (self.affine_weight + self.eps*self.eps)
      x = x * self.stdev
      if self.subtract_last:
          x = x + self.last
      else:
          x = x + self.mean
      return x

###############
##           ##
##  Getters  ##
##           ##
###############

def Get_Activation(name:str):
  """
  This function simply returns an activation function by name.
  """
  match name:
    case "elu":
      return nn.ELU()
    case "relu":
      return nn.ReLU()
    case "selu":
      return nn.SELU()
    case "celu":
      return nn.CELU()
    case "gelu":
      return nn.GELU()
    case "silu":
      return nn.SiLU()
    case "mish":
      return nn.Mish()
    case "hardswish":
      return nn.Hardswish()
    case "none":
      return nn.Identity()
    case _:
      raise "Activation not in list, choose one of the following: ['elu', 'relu', 'selu', 'celu', 'gelu', 'silu', 'mish', 'hardswish', 'none']"

class Get_Normalization(nn.Module):
  def __init__(self, name:str, channels:int, transpose:bool, affine:Optional[bool]=True, input_shape:Optional[list]=[]):
    """
    This class contains all the normalization functions that will be used and tested.
    """
    super().__init__()
    self.transpose = transpose
    match name:
      case "batch":
        self.norm = nn.BatchNorm1d(channels, affine=affine)
      case "instance":
        self.norm = nn.InstanceNorm1d(channels, affine=affine)
      case "layer":
        assert len(input_shape) > 0, "If using layer_norm, muast ensure that input_shape is non-empty."
        self.norm = nn.LayerNorm(input_shape)
      case "none":
        self.norm = nn.Identity()
      case _:
        raise "Normalization not in list, choose one of the following: ['batch', 'instance', 'layer', 'rms', 'none']"

  def forward(self, x:Tensor):
    ##  Input: [Batch, Channels, Sequence Length]
    ## Output: [Batch, Channels, Sequence Length]
    if self.transpose == True:
      x = x.transpose(-1, -2)
    x = self.norm(x)
    if self.transpose == True:
      x = x.transpose(-1, -2)
    return x

