__all__ = ["BlockRecurrent_Transformer"]

import torch
from torch import einsum, nn, Tensor
import torch.nn.functional as F
import json

from einops import rearrange, repeat
from typing import Callable, Optional

from layers.BlockRecurrent import Backbone


class Model(nn.Module):
  """
  The Block-Recurrent Time-Series Transformer.
  """
  def __init__(
    self,
    configs,
  ):
    super().__init__()
    layers = json.loads(configs.layers)
    use_patching = configs.use_patching
    input_sequence_len = configs.input_sequence_len
    output_sequence_len = configs.output_sequence_len
    c_in = configs.c_in
    num_heads = configs.num_heads
    d_ff = configs.d_ff
    proj_dim = configs.proj_dim
    state_dim = configs.state_dim
    embed_dim = configs.embed_dim
    patch_len = configs.patch_len
    stride = configs.stride
    use_cache=configs.use_cache
    use_cached_key = configs.use_cached_key
    share_queries = configs.share_queries
    reset_state = configs.reset_state
    window_size = configs.window_size
    dropout_rate = configs.dropout_rate
    attn_dropout = configs.attn_dropout
    projection_dropout = configs.projection_dropout
    head_dropout = configs.head_dropout
    bias = configs.bias
    coder_pre_attn_norm = configs.coder_pre_attn_norm
    coder_attn_log_norm = configs.coder_attn_log_norm
    coder_log_act_norm = configs.coder_log_act_norm
    coder_post_act_norm = configs.coder_post_act_norm
    coder_activation = configs.coder_activation
    res_attn = configs.res_attn
    res_ffnn = configs.res_ffnn


    projection_normalization = configs.projection_normalization
    mlp_normalization = configs.mlp_normalization

    projection_pre_norm = configs.projection_pre_norm
    mlp_activation = configs.mlp_activation
    mlp_dropout_after_activation = configs.mlp_dropout_after_activation
    use_batch_state_enc = configs.use_batch_state_enc
    affine = configs.affine
    subtract_last = configs.subtract_last
    revin = configs.revin

    use_mask = configs.use_mask
    use_state = configs.use_state

    print(layers)

    self.model = Backbone(layers, use_patching, input_sequence_len, output_sequence_len,
                          c_in, num_heads, d_ff, proj_dim, state_dim,
                          embed_dim, patch_len, stride, use_cache, use_cached_key,
                          share_queries, reset_state, window_size, dropout_rate, attn_dropout,
                          projection_dropout, head_dropout, bias, coder_pre_attn_norm,
                          coder_attn_log_norm, coder_log_act_norm, coder_post_act_norm,
                          coder_activation, res_attn, res_ffnn,
                          projection_normalization, mlp_normalization,
                          projection_pre_norm, mlp_activation, mlp_dropout_after_activation,
                          use_batch_state_enc, affine, subtract_last, revin, use_mask, use_state)

  def forward(self, x):
    x = x.permute(0,2,1)    # x: [Batch, Channel, Input length]
    x = self.model(x)
    x = x.permute(0,2,1)    # x: [Batch, Input length, Channel]
    return x